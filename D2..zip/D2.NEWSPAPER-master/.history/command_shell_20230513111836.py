
# (venv) PS D:\Учеба\D2.NEWSPAPER\NewsPapper> 
# py manage.py makemigrations
# py manage.py migrate
# py manage.py shell 
# from news.models import *
# user1 = User.objects.create(username='Veralt', first_name='Igor')
# Author.objects.create(authorUser=user1)
