from django.contrib import admin

# Register your models here.
class Author(models.Model):
    pass


class Category(models.Model):
    pass


class Post(models.Model):
    pass


class PostCategory(models.Model):
    pass


class Comment(models.Model):
    pass

